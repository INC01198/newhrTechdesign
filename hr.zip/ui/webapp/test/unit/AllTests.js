sap.ui.define([
	"sap/ui/ui/test/unit/controller/View1.controller"
], function () {
	"use strict";
});